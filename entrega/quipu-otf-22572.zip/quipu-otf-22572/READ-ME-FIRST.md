# Quipu — source delivery for OTF application #22572

Prepared 11 August 2026 for the Open Technology Fund review of application
**#22572** ("Quipu — verifiable post-quantum encoding & encryption library").

This is the complete source of Quipu. There is nothing withheld, nothing
minified and no separate "commercial edition": the licence is **AGPL-3.0** and
this is the code it covers.

## What is in this package

| File | What it is |
|---|---|
| `quipu-0.11.1-614f46c.tar.gz` | Full source at release **v0.11.1**, commit `614f46c9b5b3eba5bd6463c5db2401f5eb2c2d07` (branch `estable`) — 265 files |
| `quipu-0.11.1-614f46c.tar.gz.firma` | Hybrid signature over the tarball (see below) |
| `CLAVE-PUBLICA.txt` | The signer's public key |
| `verificar-firma` | Static Linux x86-64 binary that checks the signature. No dependencies, no network |
| `SHA256SUMS` | Checksums of the two files above |

SHA-256 of the source tarball:

    c8a0dbf4e73702590775ed18125465bd85091a19d3d02941579f354113a4d6f5

SHA-256 of `verificar-firma`:

    ab01cbc1247a1b840f24ac92c9f44f8358b81c23ed0d3282e08e486609ecb834

## About this .zip

The .zip is only the envelope, chosen because it opens everywhere without tools.
**The signature is over the `.tar.gz` inside it, not over the .zip**, so it still
verifies after your mail gateway, your extractor or a colleague forwarding it has
repacked the outside. Nothing about the envelope is trusted.

Depending on your unzip tool, `verificar-firma` may come out without its execute
bit (Python's `zipfile` drops it; `unzip` on Linux keeps it). If it will not run:

    chmod +x verificar-firma

## Verifying it

    sha256sum -c SHA256SUMS
    ./verificar-firma verificar "$(cat CLAVE-PUBLICA.txt)" \
        quipu-0.11.1-614f46c.tar.gz quipu-0.11.1-614f46c.tar.gz.firma

The tool prints its verdict in Spanish. A good delivery prints:

    FIRMA VALIDA - <file> (<n> bytes)
    Ed25519 y ML-DSA-87: las dos validan.

and exits 0. A tampered one prints `*** FIRMA INVALIDA - NO INSTALES ESTE
ARCHIVO ***` and exits 1, so the check can be scripted on the exit code alone.

The signature is **hybrid**: Ed25519 **and** ML-DSA-87 (FIPS-204). It validates
only if both validate, so an adversary who stores this delivery today and has a
quantum computer tomorrow still cannot forge a past one. Signing a library sold
on post-quantum grounds with RSA would have been a contradiction in writing.

The verifier binary is static (musl), touches no key material and makes no
network calls, so it can be inspected and run in isolation. If you would rather
not trust our binary, its source is `herramientas/` in the tarball and the
signature format is specified in `docs/SPEC.md`.

## One thing the README will get wrong

`README.md` inside the tarball still says `cargo add quipu` and
`pip install quipu-crypto`. **Those no longer resolve.** Since 10 August 2026 the
published versions on crates.io and PyPI are yanked and the source is no longer
hosted on GitHub — a decision taken after the 2026 run of supply-chain attacks on
the public registries (Shai-Hulud; ChainDrop on 4 August; a VS Code extension
that exfiltrated several thousand private repositories). For a cryptography and
evidence-custody library, hosting the source there stopped being a neutral
decision.

The README was left exactly as it shipped in v0.11.1 rather than edited for this
delivery, because an auditor should receive the released artifact and not a
version touched up for their benefit.

To build from source instead:

    tar xzf quipu-0.11.1-614f46c.tar.gz && cd quipu-0.11.1
    cargo test --workspace --all-targets     # 382 tests
    cargo build --release

## What is in the source tree

Every document that ships inside the tarball is listed here, with the language it
is written in. Roughly half of them are in Spanish, and rather than let you find
that out one file at a time, it is stated up front. **Every document that matters
for an audit is in English.** Any of the Spanish ones will be translated on
request, at no cost — just name it.

### The two manuals

| | | |
|---|---|---|
| `README.md` | EN | **The user manual.** 482 lines: what Quipu does, the API, worked examples for Rust and Python, and the operational notes |
| `docs/SPEC.md` | EN | **The technical manual.** 693 lines: formats, primitives, wire encoding, parameters, and the interoperability rules |

### For the audit

| | | |
|---|---|---|
| `docs/THREAT_MODEL.md` | EN | 713 lines. What Quipu defends against and, explicitly, what it does not |
| `docs/PRE_AUDIT.md` | EN | Written internal pre-audit: our own findings, before yours |
| `docs/ATAQUES_TAXONOMIA.md` | **ES** | 738 lines. Attack taxonomy and the tooling built to exercise it. The most directly useful document for a red team, and the one most worth asking us to translate |
| `docs/CNSA.md` | **ES** | How the parameters map to the NSA CNSA 2.0 mandate |
| `docs/ML.md` | **ES** | The machine-learning distinguisher work against the encoding |
| `docs/DISENO_NEGACION.md` | **ES** | Design of the deniable container |
| `docs/REPRODUCIBILIDAD.md` | **ES** | Reproducible-build notes |
| `INFORME_PREAUDITORIA.txt`, `MODELO_DE_AMENAZA.txt` | **ES** | Earlier Spanish editions of the pre-audit and threat model. The `docs/` versions above supersede them |

### Project and legal

| | | |
|---|---|---|
| `SECURITY.md` | EN | How to report a vulnerability to us |
| `docs/EXPORT.md` | EN | Export-control position (US 15 CFR 742.15(b) notification) |
| `CONTRIBUTING.md` | EN | Contribution process |
| `LICENSING.md` | **ES** | AGPL-3.0 plus the parallel commercial exemption |
| `LICENSE`, `LICENSE-COMMERCIAL`, `NOTICE`, `COPYRIGHT`, `TRADEMARK.md` | | Licence texts and authorship |
| `CHANGELOG.md` | ES/EN | 1365 lines of history, down to v0.1.0 |
| `docs/HOJA_DE_RUTA.md`, `docs/CONTINUIDAD.md`, `docs/RAMAS.md` | **ES** | Roadmap, continuity plan, branching model |
| `docs/RELEASES.md`, `docs/announcement.md` / `.es.md` | EN/ES | Release checklist and the launch announcements |
| `README.es.md` | **ES** | Spanish edition of the user manual. Same content as `README.md` |
| `docs/quipu-oprf-server-plan.md`, `docs/social_posts.md` | **ES** | Working notes: the OPRF server plan and draft announcement copy. Not part of the library |

### The code

| | |
|---|---|
| `src/`, `crates/` | Rust core. **Zero `unsafe` in first-party code** |
| `tests/`, `fuzz/`, `lab/` | Test suite (382 tests), fuzzing harnesses, and the security lab that attacks the library |
| `integrations/django`, `examples/` | Django integration and worked examples |
| `supply-chain/` | `cargo-vet` audit records for the dependencies |

Primitives, all standard and none invented here: XChaCha20-Poly1305, Argon2id,
HKDF, X25519 + ML-KEM-1024 (FIPS-203, X-Wing construction), Ed25519 + ML-DSA-87
(FIPS-204), ristretto255 VOPRF (RFC 9497).

## Questions

Juan Carlos Isaza Arenas — isazajuancarlos@gmail.com

Ask for anything that is missing, including a walkthrough of any part of the
code. This delivery carries no conditions: no NDA, no restriction on what you
publish about it, and no expiry.
