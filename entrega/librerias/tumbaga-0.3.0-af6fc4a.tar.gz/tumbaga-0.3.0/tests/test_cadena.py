# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""La cadena tiene que DISCRIMINAR, no solo aceptar el camino feliz.

Lo que se fija aquí es cuándo NO reescribe, cuándo NO verifica y qué pasa al
retirar un esquema antes de tiempo — que es el error caro de una migración.
"""

import bcrypt as _bcrypt
import pytest

from tumbaga import Argon2id, Bcrypt, EsquemaDesconocido, Tumbaga

CLAVE = "un-secreto-que-nadie-adivina"


@pytest.fixture
def tumbaga():
    return Tumbaga()


# --- Lo básico -------------------------------------------------------------

def test_cifra_con_argon2id_por_defecto(tumbaga):
    assert tumbaga.cifrar(CLAVE).startswith("$argon2id$")


def test_una_clave_correcta_entra(tumbaga):
    assert tumbaga.verificar(CLAVE, tumbaga.cifrar(CLAVE)).valida


def test_una_clave_incorrecta_no_entra(tumbaga):
    assert not tumbaga.verificar("otra cosa", tumbaga.cifrar(CLAVE)).valida


def test_dos_hashes_de_la_misma_clave_son_distintos(tumbaga):
    """Si fueran iguales no habría sal, y dos usuarios con la misma
    contraseña se delatarían mutuamente."""
    assert tumbaga.cifrar(CLAVE) != tumbaga.cifrar(CLAVE)


# --- La migración oportunista ---------------------------------------------

def test_un_bcrypt_heredado_se_verifica_y_se_migra(tumbaga):
    heredado = _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode()

    r = tumbaga.verificar(CLAVE, heredado)

    assert r.valida
    assert r.esquema == "bcrypt"
    assert r.hash_nuevo is not None
    assert r.hash_nuevo.startswith("$argon2id$")
    # Y el hash migrado sirve para el siguiente inicio de sesión.
    assert tumbaga.verificar(CLAVE, r.hash_nuevo).valida


def test_un_hash_ya_al_dia_no_se_reescribe(tumbaga):
    """Recifrar en cada inicio de sesión regala un Argon2 completo de CPU
    sin ganar nada."""
    al_dia = tumbaga.cifrar(CLAVE)
    assert tumbaga.verificar(CLAVE, al_dia).hash_nuevo is None


def test_una_clave_incorrecta_nunca_reescribe(tumbaga):
    """Sin la clave correcta no hay nada que volver a cifrar; hacerlo
    sobrescribiría el hash bueno con el de una contraseña equivocada."""
    heredado = _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode()
    r = tumbaga.verificar("no es la clave", heredado)
    assert not r.valida
    assert r.hash_nuevo is None


def test_subir_los_parametros_provoca_la_migracion():
    """El mismo mecanismo sirve para endurecer sin tocar la base: es lo que
    permitirá pasar de argon2id a oprf_argon2 cuando un cliente cambie de plan."""
    barato = Tumbaga(esquemas=[Argon2id(memoria_kib=8192, iteraciones=1)])
    hash_barato = barato.cifrar(CLAVE)

    caro = Tumbaga(esquemas=[Argon2id(memoria_kib=65536, iteraciones=3)])
    r = caro.verificar(CLAVE, hash_barato)

    assert r.valida
    assert r.hash_nuevo is not None, "un hash con parámetros viejos debe reescribirse"


# --- Cerrar la migración: el error caro -----------------------------------

def test_retirar_bcrypt_deja_fuera_a_quien_no_habia_entrado():
    """La prueba que justifica el informe de avance: si se saca un esquema
    antes de que todos hayan migrado, esos usuarios no pueden entrar."""
    heredado = _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode()
    sin_bcrypt = Tumbaga(esquemas=[Argon2id()])

    with pytest.raises(EsquemaDesconocido):
        sin_bcrypt.verificar(CLAVE, heredado)


def test_necesita_actualizacion_no_requiere_la_clave(tumbaga):
    """Es lo que permite medir el avance sobre toda la base de usuarios."""
    heredado = _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode()
    assert tumbaga.necesita_actualizacion(heredado)
    assert not tumbaga.necesita_actualizacion(tumbaga.cifrar(CLAVE))


def test_se_puede_contar_cuantos_faltan(tumbaga):
    base = [
        _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode(),
        _bcrypt.hashpw(CLAVE.encode(), _bcrypt.gensalt(4)).decode(),
        tumbaga.cifrar(CLAVE),
    ]
    assert sum(1 for h in base if tumbaga.necesita_actualizacion(h)) == 2


# --- Que no reviente con basura -------------------------------------------

@pytest.mark.parametrize("basura", ["", "no-es-un-hash", "$desconocido$xx", "$argon2id$roto"])
def test_un_hash_ilegible_no_verifica_en_silencio(tumbaga, basura):
    """Un hash corrupto debe fallar de forma visible o devolver False, pero
    JAMÁS dejar entrar."""
    try:
        assert not tumbaga.verificar(CLAVE, basura).valida
    except EsquemaDesconocido:
        pass  # también es una respuesta correcta: se ve el problema


def test_la_contrasena_vacia_se_rechaza_al_cifrar(tumbaga):
    with pytest.raises(ValueError):
        tumbaga.cifrar("")


# --- Configuración de la cadena -------------------------------------------

def test_una_cadena_sin_escritor_se_rechaza_al_construir():
    """Solo verificadores es una cadena que no puede crear ni actualizar
    contraseñas: mejor fallar al arrancar que descubrirlo con un usuario nuevo."""
    with pytest.raises(ValueError, match="escritura"):
        Tumbaga(esquemas=[Bcrypt()])


def test_una_cadena_vacia_se_rechaza():
    with pytest.raises(ValueError):
        Tumbaga(esquemas=[])


def test_el_escritor_es_el_primero_que_no_solo_verifica():
    tumbaga = Tumbaga(esquemas=[Bcrypt(), Argon2id()])
    assert tumbaga.escritor.nombre == "argon2id"
    assert tumbaga.cifrar(CLAVE).startswith("$argon2id$")
