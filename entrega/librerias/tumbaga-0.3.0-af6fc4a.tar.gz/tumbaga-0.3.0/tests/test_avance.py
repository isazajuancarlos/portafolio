# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""El informe de avance: lo que hace visible una migración que no avanza."""

import pytest

from tumbaga import Argon2id, Bcrypt, Tumbaga

# Argon2 real es lento a propósito. Para las pruebas se baja el costo: lo que se
# comprueba aquí es la contabilidad del informe, no la dureza del algoritmo.
BARATO = Argon2id(memoria_kib=8, iteraciones=1, paralelismo=1)


@pytest.fixture
def cadena():
    return Tumbaga([BARATO, Bcrypt(rondas=4)])


def test_base_recien_migrada_esta_completa(cadena):
    hashes = [cadena.cifrar(f"clave-{i}") for i in range(5)]
    avance = cadena.avance(hashes)

    assert avance.total == 5
    assert avance.pendientes == 0
    assert avance.desconocidos == 0
    assert avance.por_esquema == {"argon2id": 5}
    assert avance.completo
    assert avance.porcentaje == 100.0


def test_base_heredada_entera_en_bcrypt(cadena):
    viejo = Bcrypt(rondas=4)
    hashes = [viejo.cifrar(f"clave-{i}") for i in range(4)]
    avance = cadena.avance(hashes)

    assert avance.pendientes == 4
    assert avance.por_esquema == {"bcrypt": 4}
    assert not avance.completo
    assert avance.porcentaje == 0.0


def test_migracion_a_medias_cuenta_los_dos_esquemas(cadena):
    viejo = Bcrypt(rondas=4)
    hashes = [viejo.cifrar("a"), viejo.cifrar("b"), cadena.cifrar("c"), cadena.cifrar("d")]
    avance = cadena.avance(hashes)

    assert avance.total == 4
    assert avance.pendientes == 2
    assert avance.por_esquema == {"bcrypt": 2, "argon2id": 2}
    assert avance.porcentaje == 50.0
    assert not avance.completo


def test_detecta_que_la_migracion_esta_DETENIDA(cadena):
    """La prueba que justifica que este módulo exista.

    Se simula el fallo real: el punto de llamada verifica bien —todos entran,
    nadie se queja— pero olvida persistir `hash_nuevo`. Sin informe, eso es
    indistinguible de una migración terminada.
    """
    viejo = Bcrypt(rondas=4)
    almacen = [viejo.cifrar(f"clave-{i}") for i in range(10)]

    # Cien inicios de sesión correctos... sin guardar el hash devuelto.
    for vuelta in range(10):
        for i in range(10):
            resultado = cadena.verificar(f"clave-{i}", almacen[i])
            assert resultado.valida, "la verificación debe seguir funcionando"
            assert resultado.hash_nuevo is not None, "y ofrecer la actualización"
            # El olvido: no se asigna a almacen[i].

    avance = cadena.avance(almacen)
    assert avance.pendientes == 10, "el informe debe delatar que nada se migró"
    assert not avance.completo
    assert avance.porcentaje == 0.0

    # Y ahora el contraste: los mismos inicios de sesión, persistiendo.
    for i in range(10):
        resultado = cadena.verificar(f"clave-{i}", almacen[i])
        if resultado.hash_nuevo:
            almacen[i] = resultado.hash_nuevo

    assert cadena.avance(almacen).completo, "persistiendo, sí debe terminar"


def test_hash_irreconocible_se_cuenta_y_no_revienta(cadena):
    hashes = [cadena.cifrar("buena"), "{SHA}algoDeUnSistemaViejo", ""]
    avance = cadena.avance(hashes)

    assert avance.total == 3
    assert avance.desconocidos == 2
    assert avance.por_esquema == {"argon2id": 1}


def test_desconocidos_impiden_dar_por_terminada_la_migracion(cadena):
    """Cero pendientes NO basta: un irreconocible puede ser de un esquema
    retirado antes de tiempo, y cerrarla lo dejaría fuera para siempre."""
    hashes = [cadena.cifrar("buena"), "{SHA}rastroDeOtroSistema"]
    avance = cadena.avance(hashes)

    assert avance.pendientes == 0
    assert avance.desconocidos == 1
    assert not avance.completo, "no se cierra con hashes sin identificar dentro"


def test_base_vacia_no_divide_por_cero(cadena):
    avance = cadena.avance([])
    assert avance.total == 0
    assert avance.porcentaje == 100.0
    assert not avance.completo, "sin usuarios no hay nada que declarar terminado"
    assert "No hay contraseñas" in str(avance)


def test_subir_los_parametros_vuelve_a_abrir_la_migracion():
    """Si mañana se sube el costo de Argon2, los hashes viejos quedan
    pendientes solos, sin tocar la base ni escribir una migración."""
    floja = Tumbaga([Argon2id(memoria_kib=8, iteraciones=1)])
    hashes = [floja.cifrar(f"clave-{i}") for i in range(3)]
    assert floja.avance(hashes).completo

    dura = Tumbaga([Argon2id(memoria_kib=16, iteraciones=2)])
    avance = dura.avance(hashes)
    assert avance.pendientes == 3
    assert not avance.completo


def test_el_informe_se_lee(cadena):
    viejo = Bcrypt(rondas=4)
    texto = str(cadena.avance([viejo.cifrar("a"), cadena.cifrar("b")]))
    assert "50.0 %" in texto
    assert "bcrypt: 1" in texto
