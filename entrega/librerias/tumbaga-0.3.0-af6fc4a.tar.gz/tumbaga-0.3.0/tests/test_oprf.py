# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""El endurecimiento con OPRF: lo que gana, y lo que NUNCA debe hacer.

Lo que más se prueba aquí no es que funcione, sino que FALLE BIEN. Un
endurecimiento que se degrada en silencio a «sin endurecer» es peor que no
tenerlo: produce hashes que no casan con nada y oculta la pérdida de la garantía
justo en el momento en que importa.
"""

import hashlib

import pytest

from tumbaga import (
    Argon2id, Bcrypt, EndurecimientoNoDisponible, EsquemaDesconocido,
    OprfArgon2, Tumbaga,
)

# Argon2 real es lento a propósito; aquí se mide la mecánica del esquema.
BARATO = Argon2id(memoria_kib=8, iteraciones=1, paralelismo=1)


class EndurecedorFalso:
    """Doble del servicio: determinista y con clave, como el de verdad."""

    def __init__(self, k: bytes = b"clave-del-servidor"):
        self.k = k
        self.llamadas = 0

    def harden(self, password: bytes) -> bytes:
        self.llamadas += 1
        return hashlib.sha256(self.k + password).digest()


class EndurecedorCaido:
    def harden(self, password: bytes) -> bytes:
        raise ConnectionError("el servicio no responde")


class EndurecedorTramposo:
    """El modo de fallo peligroso: devuelve la contraseña sin endurecer."""

    def harden(self, password: bytes) -> bytes:
        return password


def _oprf(endurecedor=None):
    return OprfArgon2(endurecedor or EndurecedorFalso(), argon2=BARATO)


# --- Que funcione ------------------------------------------------------------

def test_ida_y_vuelta():
    e = _oprf()
    h = e.cifrar("secreta")
    assert e.verifica("secreta", h)
    assert not e.verifica("otra", h)


def test_el_hash_lleva_su_prefijo():
    h = _oprf().cifrar("secreta")
    assert h.startswith("$oprf$")


def test_la_contrasena_nunca_va_al_endurecedor_en_claro_al_almacen():
    """El hash guardado no contiene la contraseña ni el secreto en claro."""
    e = _oprf()
    h = e.cifrar("secreta")
    assert "secreta" not in h


def test_cada_verificacion_llama_al_servicio():
    """El viaje de red por inicio de sesión es el costo real de la garantía.
    Que quede explícito en una prueba, no en un comentario."""
    end = EndurecedorFalso()
    e = OprfArgon2(end, argon2=BARATO)
    h = e.cifrar("secreta")
    assert end.llamadas == 1
    e.verifica("secreta", h)
    assert end.llamadas == 2


def test_otra_clave_del_servidor_produce_otro_hash():
    """La propiedad que se compra: sin `k` no se puede reproducir el hash."""
    a = OprfArgon2(EndurecedorFalso(b"k-uno"), argon2=BARATO)
    b = OprfArgon2(EndurecedorFalso(b"k-dos"), argon2=BARATO)
    h = a.cifrar("secreta")
    assert a.verifica("secreta", h)
    assert not b.verifica("secreta", h), "con otra k no debe validar"


# --- Que falle CERRADO -------------------------------------------------------

def test_si_el_servicio_se_cae_al_cifrar_LEVANTA():
    with pytest.raises(EndurecimientoNoDisponible):
        _oprf(EndurecedorCaido()).cifrar("secreta")


def test_si_el_servicio_se_cae_al_verificar_LEVANTA_no_devuelve_False():
    """LA PRUEBA MÁS IMPORTANTE DEL MÓDULO.

    Devolver False durante una caída le diría al usuario «clave errónea», y
    acabaría restableciendo una contraseña que estaba bien.
    """
    bueno = _oprf()
    h = bueno.cifrar("secreta")

    caido = _oprf(EndurecedorCaido())
    with pytest.raises(EndurecimientoNoDisponible):
        caido.verifica("secreta", h)


def test_la_cadena_propaga_el_fallo_en_vez_de_tragarselo():
    """Lo mismo, pero a través de Tumbaga.verificar, que es la vía real."""
    h = _oprf().cifrar("secreta")
    cadena = Tumbaga([_oprf(EndurecedorCaido()), BARATO, Bcrypt(rondas=4)])
    with pytest.raises(EndurecimientoNoDisponible):
        cadena.verificar("secreta", h)


def test_un_endurecedor_que_devuelve_la_contrasena_se_RECHAZA():
    """El fallo silencioso que se está evitando: degradarse a «sin endurecer»
    produciría un hash sin la garantía, con la misma pinta que uno bueno."""
    with pytest.raises(EndurecimientoNoDisponible):
        _oprf(EndurecedorTramposo()).cifrar("una-contraseña-cualquiera")


def test_un_endurecedor_sin_endurecedor_no_se_construye():
    with pytest.raises(ValueError):
        OprfArgon2(None)


# --- Que no se confunda con Argon2id a secas ---------------------------------

def test_el_prefijo_distingue_los_dos_esquemas():
    """Sin prefijo, un hash endurecido y uno normal serían idénticos de forma y
    la cadena elegiría el esquema equivocado."""
    oprf = _oprf()
    assert oprf.reconoce(oprf.cifrar("x"))
    assert not oprf.reconoce(BARATO.cifrar("x"))
    assert not BARATO.reconoce(oprf.cifrar("x"))


def test_la_cadena_enruta_cada_hash_a_su_esquema():
    cadena = Tumbaga([_oprf(), BARATO, Bcrypt(rondas=4)])
    endurecido = cadena.cifrar("secreta")
    normal = BARATO.cifrar("secreta")
    viejo = Bcrypt(rondas=4).cifrar("secreta")

    assert cadena.esquema_de(endurecido) == "oprf_argon2"
    assert cadena.esquema_de(normal) == "argon2id"
    assert cadena.esquema_de(viejo) == "bcrypt"


# --- Migración hacia el endurecimiento ---------------------------------------

def test_activar_el_oprf_migra_a_los_existentes_al_entrar():
    """Un despliegue que contrata el endurecimiento no tiene que resetear
    contraseñas: suben solas al iniciar sesión."""
    viejo = Bcrypt(rondas=4).cifrar("secreta")
    normal = BARATO.cifrar("secreta")
    cadena = Tumbaga([_oprf(), BARATO, Bcrypt(rondas=4)])

    for antiguo in (viejo, normal):
        r = cadena.verificar("secreta", antiguo)
        assert r.valida
        assert r.hash_nuevo.startswith("$oprf$")


def test_el_avance_cuenta_lo_que_falta_por_endurecer():
    cadena = Tumbaga([_oprf(), BARATO, Bcrypt(rondas=4)])
    hashes = [cadena.cifrar("a"), BARATO.cifrar("b"), Bcrypt(rondas=4).cifrar("c")]
    avance = cadena.avance(hashes)

    assert avance.por_esquema == {"oprf_argon2": 1, "argon2id": 1, "bcrypt": 1}
    assert avance.pendientes == 2
    assert not avance.completo


# --- La trampa del camino de vuelta ------------------------------------------

def test_APAGAR_EL_OPRF_DEJA_FUERA_A_LOS_ENDURECIDOS():
    """El costo irreversible, fijado en una prueba para que nadie lo descubra en
    producción.

    Un hash endurecido SOLO puede verificarse llamando al mismo servicio con la
    misma `k`. Si se retira el esquema de la cadena, esas cuentas no se pueden
    verificar NUNCA MÁS: haría falta la contraseña en claro, que no existe.
    """
    endurecido = _oprf().cifrar("secreta")
    sin_oprf = Tumbaga([BARATO, Bcrypt(rondas=4)])

    with pytest.raises(EsquemaDesconocido):
        sin_oprf.verificar("secreta", endurecido)


def test_el_avance_marca_los_endurecidos_como_irreconocibles_sin_el_servicio():
    """Y el informe lo delata antes de que alguien apague el servicio: los
    cuenta como desconocidos, lo que impide dar la migración por terminada."""
    endurecido = _oprf().cifrar("secreta")
    sin_oprf = Tumbaga([BARATO, Bcrypt(rondas=4)])

    avance = sin_oprf.avance([endurecido, BARATO.cifrar("otra")])
    assert avance.desconocidos == 1
    assert not avance.completo


# --- Parámetros --------------------------------------------------------------

def test_subir_el_costo_de_argon2_reescribe_los_endurecidos():
    end = EndurecedorFalso()
    floja = OprfArgon2(end, argon2=Argon2id(memoria_kib=8, iteraciones=1))
    h = floja.cifrar("secreta")
    assert not floja.caducado(h)

    dura = OprfArgon2(end, argon2=Argon2id(memoria_kib=16, iteraciones=2))
    assert dura.caducado(h), "un cambio de parámetros debe pedir reescritura"
