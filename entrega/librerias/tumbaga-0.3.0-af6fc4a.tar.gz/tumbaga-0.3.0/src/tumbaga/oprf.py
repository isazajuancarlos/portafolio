# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""Endurecimiento con OPRF: Argon2id sobre un secreto, no sobre la contraseña.

    hash = Argon2id( OPRF_k(contraseña) )

La contraseña viaja CEGADA: el servidor nunca la ve. A cambio devuelve un secreto
de 32 bytes que solo puede producirse con su clave `k`. El resultado es que quien
robe la base de datos NO puede probar contraseñas por su cuenta: necesitaría `k`,
que vive en otra máquina, con límite de tasa, registro y revocación.

Esa es la propiedad entera, y de ahí se siguen dos consecuencias que conviene
tener claras ANTES de activarlo:

**Es irreversible por secreto.** Un hash escrito con endurecimiento SOLO puede
verificarse llamando al mismo servidor con la misma `k`. Si mañana se apaga el
servicio, esas contraseñas no se pueden verificar nunca más y sus dueños quedan
fuera. No hay migración de vuelta: haría falta la contraseña en claro, que no
existe. Por eso `k` no rota jamás.

**Cada inicio de sesión paga un viaje de red.** Es el costo real de la garantía.

Esta pieza NO trae cliente propio. Recibe el endurecedor por inyección, de modo
que `tumbaga` no depende de urllib, ni de HTTP, ni de un proveedor concreto: se
le puede pasar el cliente de `quipu-oprf`, un HSM, o un doble en las pruebas.
"""

from __future__ import annotations

from typing import Protocol

from .esquemas import Argon2id


class Endurecedor(Protocol):
    """Convierte una contraseña en un secreto derivado de una clave remota.

    Debe FALLAR, no devolver algo, cuando no pueda cumplir. Devolver la
    contraseña sin endurecer produciría un hash que no casa con nada y ocultaría
    la pérdida de la garantía justo cuando importa.
    """

    def harden(self, password: bytes) -> bytes: ...


class EndurecimientoNoDisponible(Exception):
    """No se pudo endurecer, y por tanto no se puede afirmar nada.

    NO es «contraseña incorrecta». Quien la capture y responda «clave errónea»
    hará que un usuario legítimo cambie su contraseña por una caída de red.
    Ver el modo degradado antes de decidir qué hacer con ella.
    """


class OprfArgon2:
    """Argon2id aplicado al secreto endurecido.

    El hash almacenado lleva un PREFIJO propio, `$oprf$`, porque sin él sería
    indistinguible de un Argon2id normal: la cadena intentaría verificarlo con el
    esquema equivocado y lo daría por contraseña incorrecta. El prefijo es lo que
    permite que convivan cuentas endurecidas y sin endurecer en la misma tabla
    durante la migración.
    """

    nombre = "oprf_argon2"
    solo_verifica = False
    PREFIJO = "$oprf$"

    def __init__(self, endurecedor: Endurecedor, argon2: Argon2id | None = None):
        if endurecedor is None:
            raise ValueError(
                "OprfArgon2 necesita un endurecedor: sin él no hay nada que lo "
                "distinga de Argon2id a secas"
            )
        self._endurecedor = endurecedor
        self._argon2 = argon2 if argon2 is not None else Argon2id()

    # --- Interno --------------------------------------------------------

    def _secreto(self, clave: str) -> str:
        """Contraseña -> 64 hex del secreto endurecido, que es lo que ve Argon2.

        FALLA CERRADO. Cualquier problema del servicio se propaga como
        `EndurecimientoNoDisponible`; nunca se cae de vuelta a la contraseña sin
        endurecer.
        """
        try:
            secreto = self._endurecedor.harden(clave.encode("utf-8"))
        except EndurecimientoNoDisponible:
            raise
        except Exception as e:  # noqa: BLE001 — red, TLS, prueba DLEQ, lo que sea
            raise EndurecimientoNoDisponible(
                f"no se pudo endurecer la contraseña: {e}"
            ) from e

        if not isinstance(secreto, (bytes, bytearray)) or len(secreto) != 32:
            raise EndurecimientoNoDisponible(
                "el endurecedor devolvió algo que no son 32 bytes; se rechaza en "
                "vez de arriesgar un hash sin la garantía"
            )
        return bytes(secreto).hex()

    # --- Interfaz de esquema --------------------------------------------

    def reconoce(self, hash_: str) -> bool:
        return hash_.startswith(self.PREFIJO)

    def cifrar(self, clave: str) -> str:
        return self.PREFIJO + self._argon2.cifrar(self._secreto(clave))

    def verifica(self, clave: str, hash_: str) -> bool:
        """Verifica contra el servicio.

        Un fallo del endurecedor SE PROPAGA, no se convierte en `False`: durante
        una caída, responder «clave errónea» empuja al usuario a restablecer una
        contraseña que estaba bien.
        """
        interno = hash_[len(self.PREFIJO):]
        return self._argon2.verifica(self._secreto(clave), interno)

    def caducado(self, hash_: str) -> bool:
        """Si conviene reescribirlo por un cambio de parámetros de Argon2.

        No detecta un cambio de `k`: eso no se detecta desde el hash, y además no
        ocurre — la clave del servicio no rota.
        """
        return self._argon2.caducado(hash_[len(self.PREFIJO):])
