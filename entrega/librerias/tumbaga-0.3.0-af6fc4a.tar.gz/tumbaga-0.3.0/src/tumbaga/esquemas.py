# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""Esquemas de hash de contraseña y la cadena que los ordena.

Un hash es de una sola vía: de `bcrypt(clave)` no se saca `clave`, y sin la
clave no se puede calcular `argon2(clave)`. Por eso NO existe forma de migrar
contraseñas con una tarea en segundo plano — solo hay un instante en toda la
vida del sistema en que la contraseña está en claro: cuando el usuario la
escribe para entrar. La migración es oportunista o no es.

El esquema viaja DENTRO del hash (`$2b$…` bcrypt, `$argon2id$…` argon2), así que
no hace falta una columna aparte que pueda desincronizarse con el dato.
"""

from __future__ import annotations

import hmac
from typing import Protocol

import bcrypt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError


class Esquema(Protocol):
    """Un algoritmo concreto de hash de contraseña."""

    nombre: str
    #: Un esquema de solo lectura verifica pero no se usa para escribir. Sirve
    #: para retirar un algoritmo sin dejar fuera a quien todavía lo tiene.
    solo_verifica: bool

    def reconoce(self, hash_: str) -> bool: ...
    def cifrar(self, clave: str) -> str: ...
    def verifica(self, clave: str, hash_: str) -> bool: ...
    def caducado(self, hash_: str) -> bool: ...


class Argon2id:
    """Argon2id, el esquema por defecto para escribir.

    Los parámetros siguen la recomendación de OWASP para 2024+ (19 MiB, 2
    iteraciones, 1 hilo). `caducado()` detecta además un cambio de parámetros:
    si mañana se sube el costo, los hashes viejos se reescriben solos al
    entrar, sin tocar la base.
    """

    nombre = "argon2id"
    solo_verifica = False

    def __init__(self, memoria_kib: int = 19456, iteraciones: int = 2, paralelismo: int = 1):
        self._ph = PasswordHasher(
            memory_cost=memoria_kib, time_cost=iteraciones, parallelism=paralelismo
        )

    def reconoce(self, hash_: str) -> bool:
        return hash_.startswith("$argon2")

    def cifrar(self, clave: str) -> str:
        return self._ph.hash(clave)

    def verifica(self, clave: str, hash_: str) -> bool:
        try:
            return self._ph.verify(hash_, clave)
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False

    def caducado(self, hash_: str) -> bool:
        try:
            return self._ph.check_needs_rehash(hash_)
        except InvalidHashError:
            return True


class Bcrypt:
    """bcrypt, SOLO PARA VERIFICAR.

    No se escribe con él: todo hash de bcrypt que se verifique con éxito se
    reescribe en el acto con el esquema de arriba. Está aquí para no dejar
    fuera a nadie si alguna vez se importan usuarios de otro sistema.

    Cuando el informe de avance diga que ya no queda ninguno, se saca de la
    cadena. Dejarlo "por si acaso" para siempre mantiene abierta una rama débil:
    ante una base filtrada, el atacante ataca por la más floja.
    """

    nombre = "bcrypt"
    solo_verifica = True

    def __init__(self, rondas: int = 12):
        self._rondas = rondas

    def reconoce(self, hash_: str) -> bool:
        return hash_.startswith(("$2a$", "$2b$", "$2y$"))

    def cifrar(self, clave: str) -> str:
        return bcrypt.hashpw(clave.encode("utf-8"), bcrypt.gensalt(self._rondas)).decode()

    def verifica(self, clave: str, hash_: str) -> bool:
        try:
            return bcrypt.checkpw(clave.encode("utf-8"), hash_.encode("utf-8"))
        except (ValueError, TypeError):
            return False

    def caducado(self, hash_: str) -> bool:
        # Siempre: cualquier bcrypt debe subir al esquema de escritura.
        return True


def comparar_seguro(a: str, b: str) -> bool:
    """Comparación en tiempo constante, para todo lo que no sea un hash."""
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))
