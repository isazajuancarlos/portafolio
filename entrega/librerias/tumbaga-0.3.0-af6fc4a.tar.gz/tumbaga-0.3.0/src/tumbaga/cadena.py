# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""La cadena de esquemas y la actualización oportunista.

    tumbaga = Tumbaga()
    valida, nuevo = tumbaga.verificar(clave, usuario.password_hash)
    if valida and nuevo:
        usuario.password_hash = nuevo   # lo persiste la aplicación, no la librería

La librería NO guarda nada. Devuelve el hash actualizado y quien llama decide
cuándo escribirlo, así sirve igual a una aplicación con SQLAlchemy que a una con
SQLModel sin saber nada de su ORM.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .avance import Avance, calcular
from .esquemas import Argon2id, Bcrypt, Esquema


class EsquemaDesconocido(ValueError):
    """El hash almacenado no lo reconoce ningún esquema de la cadena.

    Casi siempre significa que se retiró un esquema demasiado pronto: hay
    usuarios guardados con un algoritmo que la cadena ya no sabe leer.
    """


@dataclass(frozen=True)
class Resultado:
    valida: bool
    #: Hash reescrito con el esquema de escritura, o None si no hace falta.
    hash_nuevo: str | None
    #: Con qué esquema estaba guardado. Sirve para el informe de avance.
    esquema: str | None


class Tumbaga:
    """Verifica contra cualquier esquema conocido; escribe con el mejor.

    El orden importa: el PRIMER esquema que no sea `solo_verifica` es con el
    que se escribe. Los demás existen para no dejar fuera a quien todavía tiene
    un hash antiguo.
    """

    def __init__(self, esquemas: list[Esquema] | None = None):
        self.esquemas: list[Esquema] = esquemas if esquemas is not None else [
            Argon2id(),
            Bcrypt(),  # solo verifica
        ]
        if not self.esquemas:
            raise ValueError("la cadena no puede estar vacía")
        escritores = [e for e in self.esquemas if not e.solo_verifica]
        if not escritores:
            raise ValueError(
                "la cadena no tiene ningún esquema de escritura: solo podría "
                "verificar contraseñas, nunca crear ni actualizar ninguna"
            )
        self.escritor: Esquema = escritores[0]

    # --- Escribir -------------------------------------------------------

    def cifrar(self, clave: str) -> str:
        """Hash nuevo con el esquema de escritura."""
        self._validar_clave(clave)
        return self.escritor.cifrar(clave)

    # --- Verificar ------------------------------------------------------

    def verificar(self, clave: str, hash_: str) -> Resultado:
        """Verifica y, si corresponde, devuelve el hash ya actualizado.

        Una clave incorrecta NO produce reescritura: sin la clave correcta no
        hay nada que volver a cifrar, y hacerlo sobrescribiría el hash bueno
        con el de una contraseña equivocada.
        """
        esquema = self._reconocer(hash_)
        if not esquema.verifica(clave, hash_):
            return Resultado(valida=False, hash_nuevo=None, esquema=esquema.nombre)

        if esquema is self.escritor and not esquema.caducado(hash_):
            # Ya está en el mejor esquema y con los parámetros vigentes:
            # recifrar aquí regalaría un Argon2 completo en cada inicio de
            # sesión, sin ganar nada.
            return Resultado(valida=True, hash_nuevo=None, esquema=esquema.nombre)

        return Resultado(
            valida=True, hash_nuevo=self.escritor.cifrar(clave), esquema=esquema.nombre
        )

    def necesita_actualizacion(self, hash_: str) -> bool:
        """Si este hash se reescribiría en el próximo inicio de sesión.

        No necesita la contraseña: sirve para el informe de avance de la
        migración, que es lo que dice cuándo se puede cerrar.
        """
        esquema = self._reconocer(hash_)
        return esquema is not self.escritor or esquema.caducado(hash_)

    def esquema_de(self, hash_: str) -> str:
        return self._reconocer(hash_).nombre

    def avance(self, hashes: Iterable[str]) -> Avance:
        """Estado de la migración sobre los hashes que le pase la aplicación.

        Es lo que dice cuándo se puede retirar un esquema de solo lectura, y lo
        único que delata que el punto de llamada olvidó persistir `hash_nuevo`:
        sin esto, una migración detenida se ve igual que una terminada.
        """
        return calcular(self, hashes)

    # --- Interno --------------------------------------------------------

    def _reconocer(self, hash_: str) -> Esquema:
        if not isinstance(hash_, str) or not hash_:
            raise EsquemaDesconocido("el hash almacenado está vacío")
        for esquema in self.esquemas:
            if esquema.reconoce(hash_):
                return esquema
        raise EsquemaDesconocido(
            f"ningún esquema de la cadena reconoce este hash "
            f"(empieza por {hash_[:12]!r}). ¿Se retiró un esquema que todavía "
            f"tiene usuarios?"
        )

    @staticmethod
    def _validar_clave(clave: str) -> None:
        if not isinstance(clave, str) or not clave:
            raise ValueError("la contraseña no puede estar vacía")
