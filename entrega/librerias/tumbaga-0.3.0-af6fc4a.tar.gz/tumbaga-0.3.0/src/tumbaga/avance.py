# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""El informe de avance de la migración.

La actualización oportunista tiene un defecto propio: es INVISIBLE. Nadie se
entera de si está ocurriendo, porque una migración que no avanza se ve
exactamente igual que una que ya terminó — todo el mundo entra con normalidad.
Ese es justamente el modo de fallo peligroso: si el punto de llamada olvida
persistir `hash_nuevo`, el sistema sigue funcionando y nunca migra nada.

Este informe es la única forma de saberlo, y es lo que autoriza a retirar un
esquema de la cadena: mientras quede un solo hash antiguo, retirarlo deja fuera
a ese usuario.

Es una función pura sobre hashes. No sabe de ORM ni de tablas: la aplicación
sabe de dónde saca la lista, que es lo único que cambia entre un proyecto con
SQLAlchemy y otro con SQLModel.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Iterable


@dataclass(frozen=True)
class Avance:
    """Cuántas contraseñas quedan por migrar, y en qué esquema están."""

    total: int
    #: Cuántos hashes hay de cada esquema conocido.
    por_esquema: dict[str, int] = field(default_factory=dict)
    #: Cuántos se reescribirían en el próximo inicio de sesión.
    pendientes: int = 0
    #: Hashes que ningún esquema de la cadena reconoce. Ver `completo`.
    desconocidos: int = 0

    @property
    def completo(self) -> bool:
        """Si se puede retirar de la cadena todo lo que sea `solo_verifica`.

        Exige CERO desconocidos, no solo cero pendientes: un hash que nadie
        reconoce puede ser de un esquema retirado antes de tiempo, y dar la
        migración por terminada con esos dentro es dejar a alguien fuera.
        """
        return self.total > 0 and self.pendientes == 0 and self.desconocidos == 0

    @property
    def porcentaje(self) -> float:
        """Porcentaje ya migrado, de 0 a 100."""
        if self.total == 0:
            return 100.0
        return 100.0 * (self.total - self.pendientes - self.desconocidos) / self.total

    def __str__(self) -> str:
        if self.total == 0:
            return "No hay contraseñas que migrar."
        lineas = [
            f"Migración al {self.porcentaje:.1f} % "
            f"({self.total - self.pendientes - self.desconocidos} de {self.total})"
        ]
        for nombre, cuenta in sorted(self.por_esquema.items(), key=lambda kv: -kv[1]):
            lineas.append(f"  {nombre}: {cuenta}")
        if self.desconocidos:
            lineas.append(
                f"  SIN RECONOCER: {self.desconocidos} "
                f"— revisar antes de retirar ningún esquema"
            )
        if self.completo:
            lineas.append("  Terminada: ya se pueden retirar los esquemas de solo lectura.")
        return "\n".join(lineas)


def calcular(cadena, hashes: Iterable[str]) -> Avance:
    """Recorre los hashes y resume el estado de la migración.

    NO se detiene ante un hash irreconocible: los cuenta. Un informe que revienta
    con el primer dato raro es inútil precisamente en el caso que debe
    diagnosticar.
    """
    from .cadena import EsquemaDesconocido

    por_esquema: Counter[str] = Counter()
    total = pendientes = desconocidos = 0

    for hash_ in hashes:
        total += 1
        try:
            nombre = cadena.esquema_de(hash_)
        except EsquemaDesconocido:
            desconocidos += 1
            continue
        por_esquema[nombre] += 1
        if cadena.necesita_actualizacion(hash_):
            pendientes += 1

    return Avance(
        total=total,
        por_esquema=dict(por_esquema),
        pendientes=pendientes,
        desconocidos=desconocidos,
    )
