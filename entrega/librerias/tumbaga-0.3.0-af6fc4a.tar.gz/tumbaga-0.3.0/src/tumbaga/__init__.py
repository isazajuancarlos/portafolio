# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 Juan Carlos Isaza Arenas

"""tumbaga — verificación de contraseñas con actualización oportunista."""

from .avance import Avance
from .cadena import EsquemaDesconocido, Tumbaga, Resultado
from .esquemas import Argon2id, Bcrypt, Esquema, comparar_seguro
from .oprf import Endurecedor, EndurecimientoNoDisponible, OprfArgon2

__version__ = "0.3.0"
__all__ = [
    "Tumbaga", "Resultado", "EsquemaDesconocido", "Avance",
    "Argon2id", "Bcrypt", "Esquema", "comparar_seguro",
    "OprfArgon2", "Endurecedor", "EndurecimientoNoDisponible",
]
