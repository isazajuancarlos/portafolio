# CLAUDE.md — mirilla

> **Configuración general: `~/.claude/CLAUDE.md`** — reglas, directivas y
> máquinas. Se carga en toda sesión y **no se copia aquí**.

## Qué es

Una librería de PRUEBAS: conduce un Chromium sin cabeza por CDP sobre una
tubería. **Pública y MIT** (directiva 10: librería de prestigio → pública).
Nació el 2026-08-10 extraída de `medico` e `informes`, donde vivía duplicada.

## Comandos

```bash
cargo test                                  # 5 pruebas + el doctest; ARRANCAN Chromium
cargo clippy --all-targets -- -D warnings
CHROMIUM=/ruta cargo test                   # si no está en el PATH
```

## Invariantes

1. **DOS dependencias, y no crecen**: `libc` (por `pipe`/`dup`/`dup2`) y
   `serde_json` (CDP es JSON). Un arnés de pruebas que arrastra un árbol de
   paquetes es un arnés que hay que auditar. Un cliente de WebSocket entraría
   aquí si alguien cambiase la tubería por un puerto — por eso no se cambia.
2. **Falla ruidosamente si no hay navegador.** `buscar_chromium` entra en pánico
   y no devuelve `Option`: un banco que se salta solo es indistinguible de uno
   que pasa, y ése es el verde que esta librería existe para no producir.
3. **La sesión se ENTRA, no se inyecta.** Es lo que hace que el acceso quede
   medido de paso y que una cookie mal marcada se vea aquí.
4. **Lo único parametrizado es la RUTA de la entrada**, y está medido: al
   comparar las dos copias de las que salió, de ~309 líneas era la única
   diferencia real. Los nombres de los campos (`email`, `clave`) coincidían, así
   que son constantes. **No se parametriza lo que todavía no se ha repetido**
   (directiva 9): el día que un tercer consumidor traiga otros nombres, entonces.
5. **El orden de los `dup2`** (ver la cabecera de `lib.rs`): nuestros extremos se
   apartan a descriptores altos ANTES de tocar el 3 y el 4, o el arnés se lee a
   sí mismo — sin error, solo un `pedir` que nunca contesta.

## Las pruebas cruzan la frontera, y no hay dobles

Arrancan Chromium de verdad contra URLs `data:`, sin servidor. Un doble de CDP
mediría el doble, y lo único que esta librería hace es hablar con un proceso
externo por dos descriptores — que es justo lo que un doble no puede tener.

Lo que NO se puede probar así es `entrar`: un `data:` no recibe el envío de un
formulario. Esa la cubren los consumidores, que sí tienen un binario que
arrancar.

**La pareja que da valor a todo**:
`lo_que_se_lee_es_el_dom_despues_del_javascript_no_el_html_enviado`. Sin ella,
`ir` + `dom` no medirían nada que un `curl` no midiera ya.

## Cómo se consume

Por `git` + `rev` fijado, como el resto del universo fija sus dependencias
propias — nunca por tag, que es mutable:

```toml
[dev-dependencies]
mirilla = { git = "https://github.com/isazajuancarlos/mirilla", rev = "<sha>" }
```

**`dev-dependencies`**, no `dependencies`: no toca el binario de producción.

`publish = false` en el `Cargo.toml`: el repositorio es público, pero subirlo a
crates.io es una decisión aparte y cada vez (directiva 10).
