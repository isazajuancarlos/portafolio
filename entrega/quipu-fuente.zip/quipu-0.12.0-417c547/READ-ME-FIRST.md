# Quipu — source delivery, release v0.12.0

Complete source of Quipu at release **v0.12.0**, commit
`417c54710d0219f3fdd91cbd1b1da273b41ec490` (branch `estable`), prepared
17 August 2026.

Nothing is withheld, nothing is minified, and there is no separate "commercial
edition": the licence is **AGPL-3.0** and this is the code it covers.

## What is in this package

| File | What it is |
|---|---|
| `quipu-0.12.0-417c547.tar.gz` | Full source at v0.12.0 — **278 files of ours plus a vendored dependency tree of 8 429** |
| `quipu-0.12.0-417c547.tar.gz.firma` | Hybrid Ed25519 + ML-DSA-87 signature over the tarball |
| `CLAVE-PUBLICA.txt` | The signer's public key |
| `verificar-firma` | Static Linux x86-64 binary that checks the signature. No dependencies, no network |
| `SHA256SUMS` | Checksums of all of the above |

## Why it is 45 MB and the previous delivery was 1.4 MB

Because **the whole dependency tree ships inside it**. Since 14 August 2026 the
build resolves everything from `vendor/` in the repository and nothing from
crates.io — `.cargo/config.toml` replaces the registry outright. That is what
makes this delivery **buildable offline, byte for byte, without trusting a
registry**, and for an audit it is the difference between reading our code and
reading what actually gets compiled.

    278 files are ours    ·    8 429 are vendored third-party crates

If you only want to read our code: everything outside `vendor/`.

## Verifying it

    sha256sum -c SHA256SUMS
    ./verificar-firma verificar "$(cat CLAVE-PUBLICA.txt)" \
        quipu-0.12.0-417c547.tar.gz quipu-0.12.0-417c547.tar.gz.firma

A good delivery prints `FIRMA VALIDA` and exits 0; a tampered one prints
`*** FIRMA INVALIDA - NO INSTALES ESTE ARCHIVO ***` and exits 1, so the check can
be scripted on the exit code alone. The tool speaks Spanish.

The signature is **hybrid**: Ed25519 **and** ML-DSA-87 (FIPS-204), valid only if
both validate. An adversary who stores this delivery today and has a quantum
computer tomorrow still cannot forge a past one. Signing a library sold on
post-quantum grounds with RSA would have been a contradiction in writing.

The `.zip` is only the envelope. **The signature is over the `.tar.gz` inside
it**, so it survives a mail gateway or a colleague repacking the outside. If your
extractor drops the execute bit: `chmod +x verificar-firma`.

**The key fingerprint is published on a separate channel** — on the website, not
inside this package — because a key that travels only inside the thing it
authenticates proves nothing.

## Building it

    tar xzf quipu-0.12.0-417c547.tar.gz && cd quipu-0.12.0
    cargo test --workspace --all-targets      # 411 tests
    python3 herramientas/verificar.py local   # the full local gate, 14 checks

**Do not run `cargo test --all-features`.** It turns on `selftest-fault`, a
feature whose entire purpose is to inject a failure into the boot self-test, and
you will get red tests that are the feature working as designed. The optional
features are `blindaje`, `honey`, `negacion`, `escrow`, `slh`, `lab`,
`lab-offline`, `hsm`.

## Three things you should know before you read anything else

**1. `README.md` inside the tarball still says `cargo add quipu` and
`pip install quipu-crypto`. Those no longer resolve.** Since 10 August 2026 the
published versions on crates.io and PyPI are yanked and the source is no longer
hosted on GitHub — a decision taken after the 2026 run of supply-chain attacks on
the public registries. The README is left as it shipped rather than edited for
this delivery, because an auditor should receive the released artifact and not a
version touched up for their benefit. (`docs/RELEASES.md`, by contrast, *was*
corrected: it used to describe a sigstore/cosign verification that no longer
exists, and telling you to run a check that cannot pass is worse than saying
there is none.)

**2. There are NO first-party CI workflows, and that is deliberate — but the
vendored tree carries ~40 third-party ones.** Our own `.github/` holds only
`FUNDING.yml` and a `LEEME.md` explaining why the workflows were deleted on
2026-08-17: there has been no CI since 2026-08-10, the workflows promised
coverage that did not exist, and two of them were unsafe if enabled by a stranger
(`claude.yml` triggered on any issue; `release.yml` had `id-token: write`). What
remains under `vendor/*/.github/workflows/` belongs to the dependencies, is
inert here, and carries none of our identity or secrets — but if you drop the
*whole* tree onto a platform with Actions on, those third-party workflows can
still fire. The local gate is `python3 herramientas/verificar.py local`.

**3. `docs/SPEC.md` §8 and §10 are marked as out of date, inside the document
itself.** §8 specifies the proprietary OPRF construction that was **removed** —
six line-by-line divergences from RFC 9497, which is what the code implements —
and §10 misdescribes the streaming key derivation. They are flagged rather than
deleted, because deleting them would hide that the construction changed. Do not
implement a client from §8.

## What changed since v0.11.1

`CHANGELOG.md` has the detail. The short version: five independent audits went
through the library mechanism by mechanism. **None found a cryptographic break**
— no bias in the CSPRNG, no silent fallback, no wrong finite field, no plaintext
in a Shamir share, no OR combinator disguised as an AND. What they found were
measuring instruments with blind spots, and more than a dozen were closed in this
release, each with a test and a mutant proving the test discriminates.

The two most consequential, because both were invisible:

- `ml-dsa` and `ml-kem` were compiled **without `zeroize`** for anyone consuming
  this crate, so ML-DSA-87 private key material survived every signature. The
  test bench could not see it: a sibling crate in the same workspace turned the
  feature on by unification, so the measurement was made on a different binary
  than the one shipped.
- The OPRF client had **no timeouts at all**. A server that accepts the
  connection and then says nothing hung the caller indefinitely — and from
  outside, a hang looks exactly like a slow server.

And two more were introduced *while fixing others* and caught by the security
review of that same change — which is the whole reason the review runs on the
fix, not only on the original: a timeout that broke `localhost`, and a negative
test that passed with the verification switched off entirely.
